Nugget Dance!

Controls:
Right arm -> arrow keys
Left arm -> WASD

the arrow keys control direction of the right arm
the wasd keys control the direction of the left arm

each arm has 8 directions and you control the direction by the corresponding arrow key. 

eg. Left arrow key points right arm to the West direction
      Left and up arrow key points right arm to the North-West direction

      A key points left arm to the West direction
      A and W key points left arm to the North-West direction

What is it about:
Mimic the dance moves of your superior nugget counterpart to attain status of nugget superiority! 

Mimic him as close as possible to achieve and you may also get to become a member of the superior nuggets club. (They have Premium Oil Jacuzzis there, enuff said.)

But beware, failure to do so will leave you where you are, just a poor lil nugget. So, better get mimicking!

Git-repo:
https://github.com/bsweeyee/nuggetdance.git

Group name:
Nuggets

Group members:
See Wenhan
Brandon Swee
